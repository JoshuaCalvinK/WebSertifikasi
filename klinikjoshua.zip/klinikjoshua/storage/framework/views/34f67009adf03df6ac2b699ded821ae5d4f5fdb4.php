<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; Klinik 2023</div>
            <div>
                <a href="#">Privacy Policy</a>
                &middot;
                <a href="#">Terms &amp; Conditions</a>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\Users\Josh\OneDrive\Documents\BK ANJ\klinikjosua\resources\views/layouts/inc/doctor-footer.blade.php ENDPATH**/ ?>