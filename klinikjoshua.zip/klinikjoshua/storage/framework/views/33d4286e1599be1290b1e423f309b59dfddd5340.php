

<?php $__env->startSection('title', 'Pasien Dashboard'); ?>


<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
    </div>

    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="pt-5">
                <div class="card">
                    <div class="card-header text-white bg-gray">
                        <h3>Riwayat Daftar Poli</h3>
                    </div>
                    <div class="card-body">
                        <?php if(count($daftarpoli) > 0): ?>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Poli</th>
                                        <th>Dokter</th>
                                        <th>Hari</th>
                                        <th>Mulai</th>
                                        <th>Selesai</th>
                                        <th>Antrian</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $daftarpoli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->id); ?></td>
                                            <td><?php echo e($item->jadwal->dokter->poli->nama_poli); ?></td>
                                            <td><?php echo e($item->jadwal->dokter->nama); ?></td>
                                            <td><?php echo e($item->jadwal->hari); ?></td>
                                            <td><?php echo e($item->jadwal->jam_mulai); ?></td>
                                            <td><?php echo e($item->jadwal->jam_selesai); ?></td>
                                            <td><?php echo e($item->no_antrian); ?></td>
                                            <td><?php echo e($item->status == '0' ? 'PENDING' : 'DIPERIKSA'); ?></td>
                                            <td>
                                                <?php if($item->status == '0'): ?>
                                                    <a href="<?php echo e(url('pasien/delete-daftarpoli/' . $item->id)); ?>"
                                                        class="btn btn-danger">Cancel</a>
                                                <?php else: ?>
                                                    <a href="<?php echo e(url('pasien/detail-periksa/' . $item->id)); ?>" class="btn btn-primary">Detail</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <hr>
                        <?php else: ?>
                            <p>Tidak ada riwayat</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container-fluid pt-5">


        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-header text-white bg-gray">
                        <h3>Daftar Poli</h3>
                    </div>
                    <div class="card-body">
                        <hr>
                        
                        <form action="<?php echo e(url('pasien/add-daftarpoli')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="row checkout-form">
                                <div class="mt-3">
                                    <label for="no_rm">Nomer Rekam Medis</label>
                                    <input type="text" class="form-control" name="no_rm"
                                        value="<?php echo e($pasien->no_rm ?? ''); ?>" placeholder="Nomer Rekam Medis" disabled>
                                </div>

                                <div class="mt-3">
                                    <label for="jadwal">Pilih Jadwal</label>
                                    <select class="form-control" name="jadwal">
                                        <option value="" selected disabled>Pilih Jadwal</option>
                                        <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($schedule->id); ?>"><?php echo e($schedule->hari); ?> -
                                                <?php echo e($schedule->jam_mulai); ?> - <?php echo e($schedule->jam_selesai); ?> - Dr.
                                                <?php echo e($schedule->dokter->nama); ?> >> <?php echo e($schedule->dokter->poli->nama_poli); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>



                                <div class="mt-3">
                                    <label for="">Nomer Antrian</label>
                                    <input type="text" class="form-control" name='no_antrian' placeholder="Nomer Antrian"
                                        disabled>
                                </div>

                                <div class="mt-3">
                                    <label for="keluhan">Keluhan</label>
                                    <textarea class="form-control" name="keluhan" placeholder="Keluhan"></textarea>
                                </div>

                             
                            </div>

                            <button type="submit" class="mt-5 btn btn-success"></i> Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>



   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterpsn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larapp\klinikjosua\resources\views/pasien/daftarpoli.blade.php ENDPATH**/ ?>