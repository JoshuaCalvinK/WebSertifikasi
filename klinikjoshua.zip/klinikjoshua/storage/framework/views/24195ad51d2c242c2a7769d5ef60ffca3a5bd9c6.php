

<?php $__env->startSection('title', 'Edit Data Dokter'); ?>


<?php $__env->startSection('content'); ?>




    <div class="container px-4">
        <div class="card mt-4">

            <div class="card-header text-center bg-gray">
                <h4 class="waduh text-white">Edit <?php echo e($dokter->user->name); ?></h4>
                <a href="<?php echo e(url('admin/users')); ?>" class="btn float-end custom-btn">
                    <i class="fas fa-arrow-left"></i> Return
                </a>
            </div>

            <div class="card-body">

                <form action="<?php echo e(url('admin/update-dokter/' . $dokter->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>



                    <div class="mb-3">
                        <label for="">Full Name</label>
                        <input type="text" class="form-control" value="<?php echo e($dokter->nama); ?>" name="nama">
                    </div>
                    <div class="mb-3">
                        <label for="">Alamat</label>
                        <input type="text" class="form-control" value="<?php echo e($dokter->alamat); ?>" name="alamat">
                    </div>
                    <div class="mb-3">
                        <label for="">No HP</label>
                        <input type="text" class="form-control" value="<?php echo e($dokter->no_hp); ?>" name="no_hp">
                    </div>
                    <div class="mb-3">
                        <label for="">Poli</label>
                        <select name="id_poli" class="form-control">
                            <option value="" selected disabled>Pilih Poli</option>
                            <?php $__currentLoopData = $poli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poliitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($poliitem->id); ?>"><?php echo e($poliitem->nama_poli); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <hr>
                    <div class="mb-3">
                        <button class="btn btn-primary">Update dokter</button>
                    </div>
                </form>
            </div>


        </div>


    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larapp\klinik-bk\resources\views/admin/doctor/edit.blade.php ENDPATH**/ ?>