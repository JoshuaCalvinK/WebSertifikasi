;

<?php $__env->startSection('content'); ?>



    <div class="contaisner">
        <div class="row">
            <div class="card bg-dark">
                <div class="card-body text-center text-white">
                    <?php if(auth()->check()): ?>
                    <h1>Welcome <?php echo e(auth()->user()->name); ?></h1>
                    <small>
                        <?php if(auth()->user()->role_as == 0): ?>
                            You are logged in as Pasien
                        <?php elseif(auth()->user()->role_as == 1): ?>
                            You are logged in as Admin
                        <?php elseif(auth()->user()->role_as == 2): ?>
                            You are logged in as Dokter
                        <?php endif; ?>
                    <?php else: ?>
                    <h1>Welcome to My BK Klinik Project</h1>
                    <?php endif; ?>
                    </small>
                    <div class="card-body">
                        <img src="<?php echo e(asset('assets/bg2.jpg')); ?>" alt="" width="400" height="400" class="pb-3">
                        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Earum consequatur, officiis error iure
                            dolorum qui nisi, reprehenderit excepturi repellendus repudiandae saepe in temporibus
                            cupiditate, id ipsa amet assumenda. Nihil, doloremque!</p>

                        <?php if(auth()->check()): ?>
                            <?php if(auth()->user()->role_as == 0): ?>
                                <a class="btn btn-primary text-bold" href="<?php echo e(url('pasien/dashboard')); ?>">Menuju ke Dashboard
                                    Pasien</a>
                            <?php elseif(auth()->user()->role_as == 1): ?>
                                <a class="btn btn-primary" href="<?php echo e(url('admin/dashboard')); ?>">Menuju ke Dashboard Admin</a>
                            <?php elseif(auth()->user()->role_as == 2): ?>
                                <a class="btn btn-primary" href="<?php echo e(url('doctor/dashboard')); ?>">Menuju ke Dashboard Dokter</a>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="<?php echo e(route('register')); ?>" class="text-white btn btn-danger"><strong>Silakan register untuk menentukan role</strong></a>
                        <?php endif; ?>

                    </div>
                </div>
            </div>

            
        </div>
    </div>
    
    
    <div class="container">
        <div class=" mt-4 pt-4 ">
            <div class="card-body">
                <h4>Informasi Terkait</h4>
                <div class="underline"></div>
            </div>

            <div class="card-body">
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptate eaque illum id iure, minus alias doloremque aperiam eveniet esse fugit, quibusdam necessitatibus distinctio quidem ullam? Quaerat recusandae, dolorem corporis dolore odio eligendi officia? Quisquam nisi quos sed, inventore laboriosam laudantium. Nobis, voluptatum! Ducimus, cum alias reiciendis iste atque similique quis vitae accusantium, distinctio dolores corrupti ipsum architecto, ipsa dolorum unde amet porro ullam. Adipisci esse omnis possimus iste autem doloribus cumque dignissimos officiis eum animi laboriosam voluptate aliquam officia debitis recusandae amet, architecto ipsum libero repellendus illum sint saepe? Dicta ratione nisi modi architecto, ea cumque facilis dolor accusantium veniam eligendi est debitis beatae nemo, quod ullam consequatur autem maiores doloremque, consequuntur temporibus quas excepturi? Quasi delectus deserunt iste corrupti ab explicabo ratione tempore. Totam cumque ex ut molestiae quia provident laudantium nobis tenetur illum, voluptatem aliquid accusantium, obcaecati dicta asperiores alias recusandae soluta, quaerat dolorem similique nesciunt distinctio? Accusamus est repellendus dolor maiores ipsum laboriosam, recusandae nostrum ex quae debitis tempora vero. Nulla facere odit voluptas, reprehenderit omnis placeat nemo laboriosam non velit magnam voluptates quae laborum autem natus provident molestiae iste alias consequatur ducimus doloribus fugiat. Architecto dolor odit molestias nihil, nesciunt natus sint ipsam totam quasi ab.</p>
            </div>
        </div>

    </div>

    <div class="container mt-5">
        <div class="card bg-dark">
            <div class="card-body">
                <h3 class="text-white">About</h3>
                <div class="underline"></div>
                <p class="mb-5 text-white">
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptatum quam ratione debitis perspiciatis! Labore incidunt, molestiae officia iusto dolore laboriosam! Aliquam aperiam id at nesciunt fugiat hic natus consequuntur a deleniti. Nulla eveniet esse maxime officiis eaque vel necessitatibus aut, quis earum veritatis dolorum laborum dignissimos corporis nesciunt, velit, laudantium nostrum recusandae facilis. Minus, veritatis. Praesentium debitis nostrum deserunt quasi accusantium perferendis recusandae corrupti culpa ullam quas eos quo fugiat numquam inventore dolore fuga omnis doloribus consequuntur autem assumenda voluptas veritatis vitae, neque saepe. Pariatur fugit temporibus animi? Aspernatur non dicta vitae rem quia porro excepturi, tempore possimus vero, magnam quas! Enim voluptates eligendi tempora repellendus modi placeat laboriosam. Quae ab nobis, corrupti numquam mollitia sunt cumque soluta earum? Quod, quasi voluptatibus. Totam mollitia cumque aliquid ut, voluptatem neque at ducimus consequuntur animi pariatur, voluptatum doloremque! Aliquam quaerat ex eaque vero officia voluptates nesciunt placeat! Et veniam aspernatur nobis numquam officiis tempora a fugit ea aliquam sapiente molestiae itaque odit perspiciatis quidem aut quaerat commodi laboriosam, necessitatibus deleniti, similique error doloremque vel? Id tempore natus officiis quis magnam, incidunt harum consectetur, aut odit cupiditate voluptatibus aspernatur molestias ullam quo inventore, praesentium vero aperiam non. Culpa accusamus alias esse earum in reiciendis natus, voluptas dolore deserunt ipsum repudiandae officiis adipisci, sapiente consequatur aliquid illo quod temporibus architecto perspiciatis obcaecati rerum, labore commodi? Culpa, assumenda incidunt cumque non saepe facilis laudantium, consequuntur est repellendus accusantium nisi soluta, explicabo voluptas dolorum eos? Molestias libero rem sapiente fugit. Nesciunt reprehenderit nemo, corrupti quos eos dolores aut exercitationem nam est asperiores officia blanditiis assumenda placeat mollitia, necessitatibus laudantium doloribus a, eligendi aspernatur incidunt tempora hic pariatur quaerat? Officiis magnam maxime aperiam aut corrupti! Repellendus minima enim officia inventore exercitationem incidunt, aspernatur neque hic et, commodi, nulla omnis? Maiores iure exercitationem consequuntur voluptates et assumenda, ex cum veniam expedita aperiam architecto libero ratione blanditiis vitae sint corporis. Praesentium, error autem. Fugit ab voluptatibus aperiam in dolor, nostrum veritatis officiis fuga? Incidunt beatae cupiditate sunt impedit, a labore itaque quis aliquid officia asperiores quaerat velit aliquam dolorem eveniet dicta maiores odio laudantium, illo eius modi? Esse adipisci eaque qui sequi pariatur totam temporibus dolor sunt commodi. Sit rerum ad fuga ullam tempora delectus adipisci asperiores illum atque, fugiat assumenda laborum molestias consequuntur eaque porro officiis soluta fugit! Voluptatum, aliquid expedita! Magnam obcaecati possimus sit eligendi fuga natus, vel sed fugiat tenetur quibusdam maxime voluptatem deleniti nulla sint dolorum incidunt unde, culpa aliquid sunt. Porro beatae illum nihil sint tempore. Explicabo dolore molestiae rem exercitationem expedita error officiis asperiores quod dolor, illo quidem praesentium amet nulla. Eveniet, laboriosam dolor provident sed perferendis exercitationem saepe rerum, dignissimos eos, perspiciatis tempora ut ad accusamus itaque corporis in expedita quod ea delectus nulla aspernatur libero. Velit corrupti quia modi molestias? Laborum molestiae animi perspiciatis reiciendis rem exercitationem! Iste perspiciatis laudantium nesciunt officiis ducimus velit accusantium optio harum. Et possimus nulla fuga aliquam optio? Sunt minus cumque quos nemo, repellendus dolorem delectus quod asperiores tempora quasi corporis expedita. Suscipit deleniti cum non.
                </p>

                <hr>
                <div class="row" id="dabout">
      
                    <div class="col-md-6">
                        <div class="card h-100 shadow">
                            <div class="card-body">
                                <h1>Poli</h1>
                                <small>Beberapa poli yang tersedia untuk didaftar</small>
                                <hr class="mb-4">
                                <ul class="list-unstyled mb-5">
                                    <?php $__currentLoopData = $poli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="mb-2"><strong><?php echo e($item->nama_poli); ?></strong>
                                        <br><?php echo e($item->keterangan); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                
                            </div>
                        </div>
                    </div>
   
                    <div class="col-md-6">
                        <div class="card h-100 shadow">
                            <div class="card-body" id="#dcontact">
                                <h1>Contact Person</h1>
                  
                                <small></small>
                                <hr class="mb-4">
       
                                <ul class="list-unstyled mb-5">
                                    <strong>Telp: </strong><p>58385835</p>
                                    <strong>WA: </strong><p>xxxxxxxxx</p>
                                    <strong>FB: </strong><p>xxxxxxxx</p>
                                    <strong>IG: </strong><p>xxxxxxxxx</p>
                                    <strong>GMAIL: </strong><p>xxxxxxx</p>
                                </ul>


                            </div>
                        </div>
                    </div>
          
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larapp\klinik-bk\resources\views/frontend/index.blade.php ENDPATH**/ ?>