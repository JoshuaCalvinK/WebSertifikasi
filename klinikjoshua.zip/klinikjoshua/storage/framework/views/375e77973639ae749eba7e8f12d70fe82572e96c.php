<style>
    .navbar-nav a {

        transition: 0.3s ease;
    }

    .navbar-nav a:hover {
        color: black !important;

    }
</style>





<div class="sticky-top">
    <nav class="navbar navbar-expand-lg bg-body-tertiary bg-white paddingnav ">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto ">
                    <li class="nav-item">
                        <a class="nav-link btn btn-alert " href="<?php echo e(url('/')); ?>"><strong>Home</strong></a>
                    </li>
                    
                </ul>

                <ul class="navbar-nav ms-auto ml-auto">

                    <li class="nav-item dropdown mx-5">
                        <?php if(auth()->check()): ?>
                            <a class="nav-link dropdown-toggle <?php if(auth()->user()->role_as == 1): ?> text-bold <?php endif; ?>"
                                href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php echo e(auth()->user()->name); ?>

                            </a>
                            <ul class="dropdown-menu">


                                <?php if(auth()->user()->role_as == 0): ?>
                                    <a class="dropdown-item" href="<?php echo e(url('pasien/dashboard')); ?>">
                                        Dashboard</a>
                                <?php elseif(auth()->user()->role_as == 1): ?>
                                    <a class="dropdown-item" href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a>
                                <?php elseif(auth()->user()->role_as == 2): ?>
                                    <a class="dropdown-item" href="<?php echo e(url('doctor/dashboard')); ?>">Dashboard</a>
                                <?php endif; ?>


                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault(); document.getElementById('logout-form').submit()">Logout</a>
                                </li>

                                <form action="<?php echo e(route('logout')); ?>" id="logout-form" method="post" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            <?php else: ?>
                                <li class="nav-item">
                                    <a class="nav-link active " aria-current="page" href="<?php echo e(route('login')); ?>">Login</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active " aria-current="page"
                                        href="<?php echo e(route('register')); ?>">Register</a>
                                </li>
                        <?php endif; ?>
                </ul>
                </li>
                </ul>
            </div>
        </div>
       
    </nav>
    
</div>
<?php /**PATH C:\Users\Josh\OneDrive\Documents\BK ANJ\klinikjosua\resources\views/layouts/inc/frontend-navbar.blade.php ENDPATH**/ ?>