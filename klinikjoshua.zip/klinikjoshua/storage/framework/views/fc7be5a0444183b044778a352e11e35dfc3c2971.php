

<?php $__env->startSection('title','Obat'); ?>
    

<?php $__env->startSection('content'); ?>





<div class="card-body">
    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
</div>



    <div class="container px-4">
        

        
        <div class="mt-4 card">
            <div class="card-header bg-gray">
                <h4 class="text-center waduh text-white">Data Obat </h4>
                <a href="<?php echo e(url('admin/add-obat')); ?>" class="btn btn float-end custom-btn"><i class="fas fa-add"></i></a>
            </div>
            <div class="card-body">

                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama Obat</th>
                            <th>Kemasan</th>
                            <th>Harga</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->nama_obat); ?></td>
                                <td><?php echo e($item->kemasan); ?></td>
                                <td>IDR <?php echo e(number_format($item->harga, 0, '.', '.')); ?>,- </td>
                                <td>
                                    <a href="<?php echo e(url('admin/edit-obat/'.$item->id)); ?>" class="btn btn-success"><i class="fas fa-edit"></i> Edit</a>
                                    <a href="<?php echo e(url('admin/delete-obat/'.$item->id)); ?>" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</a>
                                
                                
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>


       
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larapp\klinik-bk\resources\views/admin/obat/index.blade.php ENDPATH**/ ?>