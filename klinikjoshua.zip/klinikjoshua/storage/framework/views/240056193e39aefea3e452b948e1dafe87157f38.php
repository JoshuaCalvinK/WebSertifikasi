

<?php $__env->startSection('title', 'Pasien Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
    </div>

    <div class="container-fluid pt-5">
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-header text-white bg-gray">
                        <h3>Detail Periksa</h3>
                    </div>
                    <div class="card-body">
                        <hr>
                        
                        <form action="<?php echo e(url('pasien/add-nota/' . $detail->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row checkout-form">
                                <div class="col-md-6 mt-3">
                                    <label for="tgl_periksa">Tanggal di periksa</label>
                                    <input type="date" class="form-control" name="tgl_periksa"
                                        value="<?php echo e($detail->tgl_periksa); ?>" placeholder="Tanggal di periksa" disabled>
                                </div>
                                <div class="col-md-6 mt-3">
                                    <label for="catatan">Catatan</label>
                                    <textarea class="form-control" name="catatan" disabled><?php echo e($detail->catatan); ?></textarea>
                                </div>

                                <div class="col-md-6 mt-3">
                                    <label for="obat">Obat yang disarankan Dokter</label>
                                    <input type="text" class="form-control" name="obat" value="<?php echo e($periksadetail->first()->obat->nama_obat); ?>" disabled>
                                </div>

                                <div class="col-md-12 mt-3">
                                    <h4>Total Biaya IDR <?php echo e(number_format( $periksadetail->first()->periksa->biaya_periksa, 0, '.', ',')); ?></h4>
                                </div>

                                <div class="col-md-12 text-center mt-4">
                                    <button type="submit" class="btn btn-primary">
                                        Metode Pembayaran
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterpsn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larapp\klinikjosua\resources\views/pasien/detail-periksa.blade.php ENDPATH**/ ?>