

<?php $__env->startSection('title', 'Doctor Dashboard'); ?>


<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
      
        <?php endif; ?>


    </div>


    <div class="container-fluid pt-5">

        <form action="<?php echo e(url('doctor/add-periksa/'. $dafpol->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-header text-white bg-gray">
                            <h3>Pemeriksaan</h3>
                        </div>
                        <div class="card-body">

                            <div class="mt-3">
                                <label for="nama">Nama Pasien</label>
                                <input type="text" class="form-control" disabled name="nama" value="<?php echo e($dafpol->pasien->nama); ?>">
                            </div>

                            <div class="mt-3 mb-3">
                                <label for="keluhan">Keluhan</label>
                                <textarea class="form-control" name="keluhan" placeholder="Keluhan" disabled><?php echo e($dafpol->keluhan); ?></textarea>
                            </div>

                         

                            <div class="row checkout-form">
                              
                                <div class="mb-3 mt-3">
                                    <label for="catatan">Catatan</label>
                                    <textarea class="form-control" name="catatan" placeholder="Berikan catatan kepada pasien (Catatan lama akan ditimpa dengan catatan baru)"></textarea>
                                </div>
                                
                                
                                <div class="mb-3">
                                    <label for="tgl_periksa">Tanggal Periksa</label>
                                    <input type="date" class="form-control" name="tgl_periksa" placeholder="Tanggal Periksa" disabled value="<?php echo e(now()->format('Y-m-d')); ?>">
                                </div>


                                <div class="col-md-6 mb-3">
                                    <label for="id_obat">Pilih Obat yang dianjurkan</label>
                                    <select class="form-control" name="id_obat">
                                        <option value="" selected disabled>Pilih Obat</option>
                                        <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obatitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($obatitem->id); ?>" data-harga="<?php echo e($obatitem->harga); ?>">
                                            <?php echo e($obatitem->nama_obat); ?> - IDR <?php echo e(number_format($obatitem->harga, 0, '.', ',')); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>  
                                
                                <div class="mb-3">
                                    <label for="biaya_periksa">Biaya Periksa <small> *(IDR 150.000 + Biaya Obat)</small></label>
                                    <input type="text" class="form-control" name="biaya_periksa" value="IDR <?php echo e(number_format($pemeriksaan->biaya_periksa ?? 150000, 0, '.', ',')); ?>" disabled>

                                </div>
                                

                               
                                


                            </div>
                            <button type="submit" class="mt-5 btn btn-success"></i> Update</button>
                        </div>
        </form>

    </div>
   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterdoc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larapp\klinikjosua\resources\views/doctor/periksadafpol.blade.php ENDPATH**/ ?>