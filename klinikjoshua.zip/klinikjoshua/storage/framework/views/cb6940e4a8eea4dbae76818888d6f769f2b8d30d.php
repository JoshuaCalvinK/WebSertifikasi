

<?php $__env->startSection('title', 'Doctor Dashboard'); ?>


<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>


    </div>


    <div class="container-fluid pt-5">

        <form action="<?php echo e(url('doctor/add-profil')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-header text-white bg-gray">
                            <h3>Profil Dokter</h3>
                        </div>
                        <div class="card-body">

                       
                            <div class="row checkout-form">
                                <div class=" mt-3">
                                    <label for="">Nama Lengkap</label>
                                    <input type="text" class="form-control" name='nama'
                                        value="<?php echo e($doctor->nama ?? ''); ?>" placeholder="Nama Lengkap">
                                </div>
                                <div class=" mt-3">
                                    <label for="">Nomor HP</label>
                                    <input type="text" class="form-control" name='no_hp'
                                        value="<?php echo e($doctor->no_hp ?? ''); ?>" placeholder="Nomor HP">
                                </div>

                                <div class=" mt-3">
                                    <label for="">Alamat</label>
                                    <input type="text" class="form-control" name='alamat'
                                        value="<?php echo e($doctor->alamat ?? ''); ?>" placeholder="Alamat">
                                </div>
                                <div class=" mt-3">
                                    <label for="">Poli</label>
                                    <select name="id_poli" class="form-control">

                                        <option value="" selected disabled>Pilih Poli</option>
                                        <?php $__currentLoopData = $poli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poliitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($poliitem->id); ?>"><?php echo e($poliitem->nama_poli); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                   
                                </div>

                            </div>
                            <button type="submit" class="mt-5 btn btn-success"></i> Update</button>
                        </div>
                    </div>
                </div>


        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterdoc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\OneDrive\Documents\BK ANJ\klinikjoshua\resources\views/doctor/dashboard.blade.php ENDPATH**/ ?>