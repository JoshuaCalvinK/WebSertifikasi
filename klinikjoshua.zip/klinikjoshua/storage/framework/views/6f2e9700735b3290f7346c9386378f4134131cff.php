

<?php $__env->startSection('title', 'Doctor Dashboard'); ?>


<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
      
        <?php endif; ?>


    </div>


    <div class="container-fluid pt-5">

        <form action="<?php echo e(url('doctor/add-jadwal')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-header text-white bg-gray">
                            <h3>Jadwal Praktek</h3>
                        </div>
                        <div class="card-body">

                          
                            <div class="row checkout-form">
                                <div class="mt-3">
                                    <label for="hari">Hari</label>
                                    <select class="form-control" name="hari">
                                        <option value="" disabled selected>Pilih hari</option>
                                        <option value="Senin">Senin</option>
                                        <option value="Selasa">Selasa</option>
                                        <option value="Rabu">Rabu</option>
                                        <option value="Kamis">Kamis</option>
                                        <option value="Jumat">Jumat</option>
                                        <option value="Sabtu">Sabtu</option>
                                        <option value="Minggu">Minggu</option>
                                    </select>
                                </div>
                                <div class="mt-3">
                                    <label for="jam_mulai">Jam Mulai</label>
                                    <input type="time" class="form-control" name="jam_mulai" placeholder="Jam Mulai">
                                </div>

                                <div class="mt-3">
                                    <label for="jam_selesai">Jam Selesai</label>
                                    <input type="time" class="form-control" name="jam_selesai" placeholder="Jam Selesai">
                                </div>



                            </div>
                            <button type="submit" class="mt-5 btn btn-success"></i> Add</button>
                        </div>
        </form>

    </div>


    <div class="container-fluid p-5">

        <h4>Jadwal anda:</h4>
      

        <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p>
                
                <?php echo e($schedule->hari); ?> : <?php echo e($schedule->jam_mulai); ?> - <?php echo e($schedule->jam_selesai); ?>

                <a href="<?php echo e(url('doctor/delete-jadwal/' . $schedule->id)); ?>" class="kecil btn btn-danger btn-sm">     Hapus</a>
            </p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterdoc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\OneDrive\Documents\BK ANJ\klinikjosua\resources\views/doctor/jadwal.blade.php ENDPATH**/ ?>