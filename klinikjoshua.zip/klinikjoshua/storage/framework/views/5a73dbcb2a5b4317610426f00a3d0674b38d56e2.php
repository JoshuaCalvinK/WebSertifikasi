




<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            
            <div class="nav">
             
             
                <a class="nav-link <?php echo e(Request::is('admin/dashboard') ? 'active':''); ?>" href="<?php echo e(url('admin/dashboard')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
              
                 
                 <a class="nav-link <?php echo e(Request::is('admin/users') ? 'active':''); ?>" href="<?php echo e(url('admin/users')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                    Users
                </a>

                
                <a class="nav-link <?php echo e(Request::is('admin/data-pasien') ? 'active':''); ?>" href="<?php echo e(url('admin/data-pasien')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                    Pasien
                </a>

                
                <a class="nav-link <?php echo e(Request::is('admin/data-dokter') ? 'active':''); ?>" href="<?php echo e(url('admin/data-dokter')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                    Dokter
                </a>

                
               


                
                <a class="nav-link <?php echo e(Request::is('admin/obat') || Request::is('admin/add-obat') || Request::is('admin/edit-obat/*') ? 'collapse active':'collapsed'); ?>" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts"
                    aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-database"></i></div>
                    Obat
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse <?php echo e(Request::is('admin/obat') || Request::is('admin/add-obat') || Request::is('admin/edit-obat/*') ? 'show':''); ?>" id="collapseLayouts" aria-labelledby="headingOne"
                    data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link <?php echo e(Request::is('admin/add-obat') ? 'active':''); ?>" href="<?php echo e(url('admin/add-obat')); ?>">Tambah Obat</a>
                        <a class="nav-link <?php echo e(Request::is('admin/obat') || Request::is('admin/edit-obat/*') ? 'active':''); ?>" href="<?php echo e(url('admin/obat')); ?>">Lihat Obat</a>
                    </nav>
                </div>


                
                

                <a class="nav-link <?php echo e(Request::is('admin/poli') || Request::is('admin/add-poli') || Request::is('admin/edit-poli/*') ? 'collapse active':'collapsed'); ?>" href="#" data-bs-toggle="collapse" data-bs-target="#collapsePost"
                    aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-hospital"></i></div>
                    Poli
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse <?php echo e(Request::is('admin/poli') || Request::is('admin/add-poli') || Request::is('admin/edit-poli/*') ? 'show':''); ?>" id="collapsePost" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link <?php echo e(Request::is('admin/add-poli') ? 'active':''); ?>" href="<?php echo e(url('admin/add-poli')); ?>">Tambah Poli</a>
                        <a class="nav-link <?php echo e(Request::is('admin/poli') || Request::is('admin/edit-poli/*') ? 'active':''); ?>" href="<?php echo e(url('admin/poli')); ?>">Lihat Poli</a>
                    </nav>
                </div>
                
                
            </div>
        </div>
        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            ADMIN
        </div>
    </nav>
</div><?php /**PATH C:\larapp\klinik-bk\resources\views/layouts/inc/admin-sidebar.blade.php ENDPATH**/ ?>