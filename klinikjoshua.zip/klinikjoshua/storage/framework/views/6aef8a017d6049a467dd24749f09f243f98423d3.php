

<?php $__env->startSection('title', 'Doctor Dashboard'); ?>


<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>


    </div>


    <div class="container pt-5">




        <div class="card">
            <div class="card-header bg-gray waduh text-center text-white">
                <h4>Pemeriksaan</h4>
            </div>
            <div class="card-body">
                <h4>Pasien yang minta diperiksa</h4>
                <div class="underline"></div>

                <table class="table">
                    <thead>
                        <tr>
                            <th>No. Antrian</th>
                            <th>Nama Pasien</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        

                        <?php $__currentLoopData = $dafpoli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftarPoli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <?php if($daftarPoli->status == '0'): ?> 
                                <tr>
                                    <td><?php echo e($daftarPoli->no_antrian); ?></td>
                                    <td><?php echo e($daftarPoli->pasien->nama); ?></td>
                                    <td><?php echo e($daftarPoli->status == '0' ? 'PENDING' : 'COMPLETED'); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('doctor/periksa-dafpol/' . $daftarPoli->id)); ?>" class="btn btn-success">Periksa</a>
                                        <a href="<?php echo e(url('doctor/kelola-dafpol/' . $daftarPoli->id)); ?>" class="btn btn-primary">Kelola</a>
                                        
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

            </div>
        </div>


    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterdoc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larapp\klinik-bk\resources\views/doctor/periksa.blade.php ENDPATH**/ ?>