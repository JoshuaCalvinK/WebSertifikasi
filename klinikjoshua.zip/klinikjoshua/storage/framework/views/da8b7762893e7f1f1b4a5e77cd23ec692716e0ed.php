

<?php $__env->startSection('title', 'Doctor Dashboard'); ?>


<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
      
        <?php endif; ?>


    </div>


    <div class="container-fluid pt-5">

        <form action="<?php echo e(url('doctor/update-dafpol/'. $dafpol->id)); ?>" method="POST">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-header text-white bg-gray">
                            <h3>Kelola Pemeriksaan</h3>
                        </div>
                        <div class="card-body">

                           
                            <div class="row checkout-form">
                                <div class="mb-3">
                                    <label for="">Status</label><br>
                                    <select name="status" class="form-control">
                                        <option value="0" <?php echo e($dafpol->status == '0' ? 'selected' : ''); ?>>PENDING</option>
                                        <option value="1" <?php echo e($dafpol->status == '1' ? 'selected' : ''); ?>>COMPLETED</option>
                                      </select>
                                </div>

                            </div>
                            <button type="submit" class="mt-5 btn btn-success"></i> Update</button>
                        </div>
        </form>

    </div>
   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterdoc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\OneDrive\Documents\BK ANJ\klinikjoshua\resources\views/doctor/keloladafpol.blade.php ENDPATH**/ ?>