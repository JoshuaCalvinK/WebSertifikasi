
<style>
    .sb-sidenav {
        width: 250px !important; /* Set the desired width for the sidebar */

    }
    

 
</style>



<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            
            <div class="nav">
             
                <a class="nav-link <?php echo e(Request::is('doctor/dashboard') ? 'active':''); ?>" href="<?php echo e(url('doctor/dashboard')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                <a class="nav-link <?php echo e(Request::is('doctor/jadwal') ? 'active':''); ?>" href="<?php echo e(url('doctor/jadwal')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-calendar"></i></div>
                    Jadwal Periksa
                </a>
                <a class="nav-link <?php echo e(Request::is('doctor/periksa') ? 'active':''); ?>" href="<?php echo e(url('doctor/periksa')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Memeriksa Pasien
                </a>
                <a class="nav-link <?php echo e(Request::is('doctor/riwayat') ? 'active':''); ?>" href="<?php echo e(url('doctor/riwayat')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-clipboard"></i></div>
                    Riwayat Pasien
                </a>
              
              

           
                
            </div>
        </div>
        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            Dr. <?php echo e(auth()->user()->name); ?>

        </div>
    </nav>
</div><?php /**PATH C:\Users\Josh\OneDrive\Documents\BK ANJ\klinikjosua\resources\views/layouts/inc/doctor-sidebar.blade.php ENDPATH**/ ?>