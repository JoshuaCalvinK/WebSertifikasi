<?php $__env->startSection('content'); ?>
    <style>
        .waduh {
            font-size: 44px;
            font-weight: bold;
        }

        .waduhai {
            font-size: 44px !important;
        }
    </style>


    <div class="container paddingbanyak">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header py-5 waduh bg-gray text-white text-center"><i class="fas fa-check"></i> Notification</div>

                    <div class="card-body">

                        <h4 class="waduh text-center">Welcome <?php echo e(auth()->user()->name); ?></h4>


                        <?php if(session('status')): ?>
                            <div class="text-center alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        

                      
                            <div class="row justify-content-center pt-3">
                                <div class="col-md-8 text-center"> <!-- Menambahkan kelas "text-center" untuk penataan tengah -->
                                    <div>
                                        <a href="<?php echo e(url('/')); ?>" class="btn btn-primary text-center">Direct to Home</a>
                                    </div>
                                </div>
                            </div>
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larapp\klinikjosua\resources\views/home.blade.php ENDPATH**/ ?>