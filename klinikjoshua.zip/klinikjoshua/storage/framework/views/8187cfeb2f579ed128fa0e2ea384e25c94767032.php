

<?php $__env->startSection('title','Poli'); ?>
    

<?php $__env->startSection('content'); ?>
<div class="card-body">
    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

   
</div>
    <div class="container px-4">
        


        <div class="mt-4 card">
            <div class="card-header bg-gray">
                <h4 class="text-center waduh text-white">Tambahkan Poli </h4>
                <a href="<?php echo e(url('admin/poli')); ?>" class="btn btn float-end custom-btn"><i class="fas fa-arrow-left"></i> Return</a>
                
            </div>



            <div class="card-body">

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>



                <form action="<?php echo e(url('admin/add-poli')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label for="">Nama poli</label>
                        <input type="text" name="nama_poli" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="">Keterangan</label>
                        <input type="text" name="keterangan" class="form-control">
                    </div>
                   
                    <div class="col-md-6">
                        <button type="submit" class="btn btn-primary">Tambahkan</button>
                    </div>

                </form>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larapp\klinik-bk\resources\views/admin/poli/create.blade.php ENDPATH**/ ?>