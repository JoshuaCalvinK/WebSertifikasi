

<?php $__env->startSection('title', 'Doctor Dashboard'); ?>


<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>


    </div>


    <div class="container-fluid pt-5">




        <div class="card">
            <div class="card-header bg-gray waduh text-center text-white">
                <h4>Riwayat Pemeriksaan</h4>
            </div>
            <div class="card-body">
                
                <div class="underline"></div>

                <table class="table text-center">
                    <thead>
                        <tr>
                            <th>No. Antrian</th>
                            <th>Nama Pasien</th>
                            <th>Status</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        

                        <?php $__currentLoopData = $dafpoli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftarPoli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <?php if($daftarPoli->status == '1'): ?> 
                                <tr>
                                    <td><?php echo e($daftarPoli->no_antrian); ?></td>
                                    <td><?php echo e($daftarPoli->pasien->nama); ?></td>
                                    <td><?php echo e($daftarPoli->status == '0' ? 'PENDING' : 'COMPLETED'); ?></td>
                                    
                                    
                                </tr>
                            
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

            </div>
        </div>


    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterdoc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\OneDrive\Documents\BK ANJ\klinikjoshua\resources\views/doctor/riwayat.blade.php ENDPATH**/ ?>