@extends('layouts.app')

@section('content')



    <div class="container pt-4">
        <div class="row">
            <div class="card bg-gray">
                <div class="card-body text-center">
                    @if (auth()->check())
                    <h1>
                        @if(auth()->user()->role_as == 0)
                            You are logged in as Pasien
                        @elseif(auth()->user()->role_as == 1)
                            You are logged in as Admin
                        @elseif(auth()->user()->role_as == 2)
                            You are logged in as Dokter
                        @endif
                    @else
                    <h1>Welcome!</h1>
                    @endif
                    </h1>
                    <div class="card-body">
                        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Earum consequatur, officiis error iure
                            dolorum qui nisi, reprehenderit excepturi repellendus repudiandae saepe in temporibus
                            cupiditate, id ipsa amet assumenda. Nihil, doloremque!</p>

                        @if (auth()->check())
                            @if (auth()->user()->role_as == 0)
                                <a class="btn btn-primary text-bold" href="{{ url('pasien/dashboard') }}">Menuju ke Dashboard
                                    Pasien</a>
                            @elseif (auth()->user()->role_as == 1)
                                <a class="btn btn-primary" href="{{ url('admin/dashboard') }}">Menuju ke Dashboard Admin</a>
                            @elseif (auth()->user()->role_as == 2)
                                <a class="btn btn-primary" href="{{ url('doctor/dashboard') }}">Menuju ke Dashboard Dokter</a>
                            @endif
                        @else
                            <a href="{{ route('register') }}" class="text-white btn btn-primary"><strong>Get Started!</strong></a>
                        @endif

                    </div>
                </div>
            </div>

            
        </div>
    </div>
    
    
    <div class="container">
        <div class=" mt-4 pt-4 ">
            <div class="card-body">
                <h4>Sambutan</h4>
                <div class="underline"></div>
            </div>

            <div class="card-body">
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptate eaque illum id iure, minus alias doloremque aperiam eveniet esse fugit, quibusdam necessitatibus distinctio quidem ullam? Quaerat recusandae, dolorem corporis dolore odio eligendi officia? Quisquam nisi quos sed, inventore laboriosam laudantium. Nobis, voluptatum! Ducimus, cum alias reiciendis iste atque similique quis vitae accusantium, distinctio dolores corrupti ipsum architecto, ipsa dolorum unde amet porro ullam. Adipisci esse omnis possimus iste autem doloribus cumque dignissimos officiis eum animi laboriosam voluptate aliquam officia debitis recusandae amet, architecto ipsum libero repellendus illum sint saepe? Dicta ratione nisi modi architecto, ea cumque facilis dolor accusantium veniam eligendi est debitis beatae nemo, quod ullam consequatur autem maiores doloremque, consequuntur temporibus quas excepturi? Quasi delectus deserunt iste corrupti ab explicabo ratione tempore. Totam cumque ex ut molestiae quia provident laudantium nobis tenetur illum, voluptatem aliquid accusantium, obcaecati dicta asperiores alias recusandae soluta, quaerat dolorem similique nesciunt distinctio? Accusamus est repellendus dolor maiores ipsum laboriosam, recusandae nostrum ex quae debitis tempora vero. Nulla facere odit voluptas, reprehenderit omnis placeat nemo laboriosam non velit magnam voluptates quae laborum autem natus provident molestiae iste alias consequatur ducimus doloribus fugiat. Architecto dolor odit molestias nihil, nesciunt natus sint ipsam totam quasi ab.</p>
            </div>
        </div>

    </div>

    

@endsection
